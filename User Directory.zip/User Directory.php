<?php
/*
Plugin Name: User Directory
Description: Añade un directorio de usuarios con sus redes sociales
Version: 1.1
Author: <a href="https://fj.mk" target="_blank">FJ</a>  | <a href="https:/digitablesolutions.com" target="_blank">Digitable Solutions</a> 
*/

// Enqueue Font Awesome if necessary
function enqueue_font_awesome_if_needed() {
    if (!wp_script_is('font-awesome', 'enqueued')) {
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css', array(), null);
    }
}
add_action('wp_enqueue_scripts', 'enqueue_font_awesome_if_needed');

// Enqueue jQuery if necessary
function enqueue_jquery_if_needed() {
    if (!wp_script_is('jquery', 'enqueued')) {
        wp_enqueue_script('jquery');
    }
}
add_action('wp_enqueue_scripts', 'enqueue_jquery_if_needed');

// Define constant for user category taxonomy
define('USER_CATEGORY', 'user_category');

// Register custom taxonomy for users
function register_user_taxonomy() {
    register_taxonomy(
        USER_CATEGORY,
        'user',
        array(
            'label' => 'User Category',
            'rewrite' => array('slug' => 'user-category'),
            'hierarchical' => true,
        )
    );
}
add_action('init', 'register_user_taxonomy');

// Add user category tab
function add_user_category_tab() {
    add_users_page('User Categories', 'User Categories', 'edit_users', 'edit-tags.php?taxonomy=' . USER_CATEGORY);
}
add_action('admin_menu', 'add_user_category_tab');

// Display category field in user profile
function display_user_category_field($user) {
    $user_category = get_user_meta($user->ID, 'user_category', true);
    ?>
    <h3>User Category</h3>
    <table class="form-table">
        <tr>
            <th><label for="user_category">Select Category</label></th>
            <td>
                <?php
                $terms = get_terms(USER_CATEGORY, array('hide_empty' => false));

                if (!empty($terms)) {
                    ?>
                    <select name="user_category" id="user_category">
                        <option value="">Select Category</option>
                        <?php
                        foreach ($terms as $term) {
                            echo '<option value="' . esc_attr($term->slug) . '" ' . selected($user_category, $term->slug, false) . '>' . esc_html($term->name) . '</option>';
                        }
                        ?>
                    </select>
                    <?php
                } else {
                    echo 'No categories available. Please create categories in the User Categories section.';
                }
                ?>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'display_user_category_field');
add_action('edit_user_profile', 'display_user_category_field');

// Save category and associate with user on profile update
function save_user_category($user_id) {
    if (current_user_can('edit_user', $user_id)) {
        $selected_category = sanitize_text_field($_POST['user_category']);
        update_user_meta($user_id, 'user_category', $selected_category);
        wp_set_object_terms($user_id, $selected_category, USER_CATEGORY, false);
    }
}
add_action('personal_options_update', 'save_user_category');
add_action('edit_user_profile_update', 'save_user_category');

// Add custom column on user page
function add_user_category_column($columns) {
    $columns['user_category'] = 'Category';
    return $columns;
}
add_filter('manage_users_columns', 'add_user_category_column');

// Display content in custom column without filtering link
function display_user_category_content($value, $column_name, $user_id) {
    if ('user_category' === $column_name) {
        $user_category = wp_get_object_terms($user_id, USER_CATEGORY);
        if (!empty($user_category)) {
            $category = array_shift($user_category);
            $category_name = esc_html($category->name);
            return $category_name;
        } else {
            return 'Uncategorized';
        }
    }
    return $value;
}
add_action('manage_users_custom_column', 'display_user_category_content', 10, 3);

// Shortcode to display users by category
function display_users_by_category_shortcode($atts) {
    ob_start();
    // Display available categories
    $categories = get_terms(USER_CATEGORY, array('hide_empty' => false));
    if (!empty($categories)) {
        echo '<div class="category-filter">';
        echo '<a class="category-filter" data-category="all" href="#">All Categories</a>';
        foreach ($categories as $category) {
            echo '<a class="category-filter" data-category="' . esc_attr(sanitize_title($category->name)) . '" href="#">' . esc_html($category->name) . '</a>';
        }
        echo '</div>';
    }

    // Display user boxes
    $args = array(
        'role' => 'subscriber',
    );
    $users = get_users($args);
    if (!empty($users)) {
        echo '<div class="user-boxes-wrapper">';
        foreach ($users as $user) {
            $user_data = get_userdata($user->ID);
            $avatar_url = esc_url(get_user_meta($user->ID, 'avatar_url', true));
            $avatar_html = '<img src="' . $avatar_url . '" alt="Avatar" width="300" height="200" class="user-avatar">';
            $user_category = wp_get_object_terms($user->ID, USER_CATEGORY);
            $category = !empty($user_category) ? array_shift($user_category)->name : 'Uncategorized';
            $full_name = esc_html($user_data->first_name . ' ' . $user_data->last_name);
            $email = $user_data->user_email;
            $website = esc_url($user_data->user_url);
            echo '<div class="user-box category-' . esc_attr(sanitize_title($category)) . '">';
            echo '<div class="user-avatar">' . $avatar_html . '</div>';
            echo '<div class="user-info">';
            echo '<div class="category" data-label="Category"><span class="category-filter" data-category="' . esc_attr(sanitize_title($category)) . '">' . esc_html($category) . '</span></div>';
            echo '<div class="name" data-label="Name"><i class="fas fa-user"></i> ' . $full_name . '</div>';
            echo '<div class="email" data-label="Email"><i class="fas fa-envelope"></i> ' . esc_html($email) . '</div>';
            echo '<div class="website" data-label="Website"><i class="fas fa-globe"></i> ' . esc_html($website) . '</div>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
    } else {
        echo 'No users available.';
    }

    // Add jQuery script for handling filtering
    ?>
    <script>
        jQuery(document).ready(function($) {
            $('.category-filter').on('click', function() {
                var category = $(this).data('category');
                $('.user-box').hide();
                if (category === 'all') {
                    $('.user-box').show();
                } else {
                    $('.category-' + category).show();
                }
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('display_users_by_category', 'display_users_by_category_shortcode');

// Define function to add styles to user table
function user_table_style() {
    echo '<style>
    .category-filter {
        text-align: center;
        margin-bottom: 20px;
    }

    .category-filter {
        display: inline-block;
        padding: 8px 16px;
        margin: 5px;
        background-color: Transparent;
        color: #4286F3;
        text-decoration: none;
        border: 1px solid #4286F3;
        border-radius: 4px;
        cursor: pointer;
    }

    .category-filter:hover {
        background-color: #4286F3;
        color:white;
    }

    .user-boxes-wrapper {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        max-width: 800px;
        margin: 0 auto;
    }

    .user-box {
        width: calc(33.33% - 20px);
        margin-bottom: 20px;
        border: 1px solid #ddd;
        padding: 50px;
        box-sizing: border-box;
        text-align: center;
        transition: box-shadow 0.3s ease;
    }

    .user-box .user-avatar {
        margin-bottom: 10px;
        text-align:left;
    }
    .user-avatar img {
        border-radius: 5%;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
    }

    .user-box .user-info {
        font-size: 14px;
        text-align:left;
    }
    .user-info .name,
    .user-info .email,
    .user-info .website,
    .user-info .category {
        margin-bottom: 10px;
    }

    /* Styles for social media section */
    .social-media {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
        float:left;
    }

    .social-media div {
        margin-right: 10px;
    }

    .social-media a {
        text-decoration: none;
        color: #333;
        display: flex;
        align-items: center;
    }

    .social-media i {
        font-size: 24px;
        margin-right: 5px;
        color: #4286F3;
    }

    /* Styles specific to each social media */
    .whatsapp i {
        color: #25D366;
    }

    .facebook i {
        color: #1877F2;
    }

    .instagram i {
        color: #E4405F;
    }

    .linkedin i {
        color: #0077B5;
    }

    /* Styles for small screens */
    @media only screen and (max-width: 600px) {
        .user-box {
            width: 100%;
        }
    }
</style>';
}
add_action('wp_head', 'user_table_style');

?>
